hook.Add( "PostGamemodeLoaded", "ItemStoreDarkRP", function()
	if ( DarkRP ) then
		DarkRP.declareChatCommand( { command = "pickup", description = "Picks up the item in front of you.", delay = 2 } )
		DarkRP.declareChatCommand( { command = "trade", description = "Trade with a player.", delay = 2 } )
		DarkRP.declareChatCommand( { command = "inv", description = "Shows the inventory.", delay = 2 } )
		
		if SERVER then
			util.AddNetworkString( "ItemStoreTradeCommand" )
			DarkRP.defineChatCommand( "inv", function( pl ) local w, h = unpack( pl:GetInventoryDimensions() ) itemstore.containers.Open( pl, pl:GetInventory(), "Inventory", w, h, true ) return "" end )
			DarkRP.defineChatCommand( "pickup", function( pl ) pl:PickupItem() return "" end )
			DarkRP.defineChatCommand( "trade", function( pl, args )
				local target = pl:GetEyeTrace().Entity
				
				if ( args ~= "" ) then
					for _, findpl in ipairs( player.GetAll() ) do
						if ( IsValid( findpl ) and findpl ~= pl and string.find( string.lower( findpl:Name() ), string.lower( args ) ) ) then
							target = findpl
							break
						end
					end
				end
				
				if ( IsValid( target ) and target:IsPlayer() ) then
					net.Start( "ItemStoreTradeCommand" )
						net.WriteInt( tonumber( target:EntIndex() ), 32 )
					net.Send( pl )
				else
					pl:PrintMessage( HUD_PRINTTALK, "Couldn't initialize trade: no player with that name." )
				end
				
				return ""
			end )
		else
			net.Receive( "ItemStoreTradeCommand", function()
				RunConsoleCommand( "itemstore_trading_start", net.ReadInt( 32 ) )
			end )
		end
		
		AddEntity( "Large Container", "itemstore_box_large", "models/props/cs_office/Cardboard_box01.mdl", 100, 3, "buylargebox" )
		AddEntity( "Small Container", "itemstore_box_small", "models/props/cs_office/Cardboard_box02.mdl", 50, 3, "buysmallbox" )
	end
end )