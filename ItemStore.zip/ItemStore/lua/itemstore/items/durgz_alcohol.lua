ITEM.Name = "Alcohol"
ITEM.Description = "The perfect driving companion."
ITEM.Model = "models/drug_mod/alcohol_can.mdl"
ITEM.Base = "base_darkrp"