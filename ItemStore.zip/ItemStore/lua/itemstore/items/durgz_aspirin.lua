ITEM.Name = "Aspirin"
ITEM.Description = "Dude, I just REALLY have a headache. I'm not addicted."
ITEM.Model = "models/jaanus/aspbtl.mdl"
ITEM.Base = "base_darkrp"