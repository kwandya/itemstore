ITEM.Name = "DarkRP Item Base"
ITEM.Description = "Yep!"
ITEM.Model = "models/error.mdl"

function ITEM:Load()
	self:RegisterPickup( self.UniqueName )
end

function ITEM:SpawnEntity( pos )
	local ent = ents.Create( self.UniqueName )
	ent:SetPos( pos )
	
	return ent
end

if SERVER then
	CreateConVar( "itemstore_darkrp_ignoreowner", 1, FCVAR_ARCHIVE )
	
	function ITEM:CanPickup( pl, ent )
		if ( ent.dt and ent.dt.owning_ent ) then
			if ( GetConVarNumber( "itemstore_darkrp_ignoreowner" ) == 1 or ent:Getowning_ent() == pl ) then
				return true
			else
				pl:PrintMessage( HUD_PRINTTALK, "That entity doesn't belong to you!" )
				return false
			end
		end
		
		return true
	end
end