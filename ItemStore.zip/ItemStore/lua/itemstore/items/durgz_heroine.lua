--"I know the folder "heroine" isn't right but I wanted the files to overwrite instead of having two files, heroine and heroin. So I just kept it as-is."
-- In other news, the author for durgzmod is retarded.

ITEM.Name = "Heroin"
ITEM.Description = "I don't NEED it man, I just WANT it."
ITEM.Model = "models/katharsmodels/syringe_out/syringe_out.mdl"
ITEM.Base = "base_darkrp"