ITEM.Name = "Shipment"
ITEM.Description = "A shipment of guns.\n\nContents: %s\nAmount: %d"
ITEM.Model = "models/Items/item_item_crate.mdl"
ITEM.Base = "base_darkrp"

function ITEM:GetDescription()
	return string.format( self.Description, CustomShipments[ self:GetData( "Contents" ) ].name, self:GetData( "Amount" ) )
end

function ITEM:SaveData( ent )
	self:SetData( "Owner", ent:Getowning_ent() )
	self:SetData( "Contents", ent:Getcontents() )
	self:SetData( "Amount", ent:Getcount() )
	
	timer.Destroy( ent:EntIndex() .. "crate" )
end

function ITEM:LoadData( ent )
	ent:Setcontents( self:GetData( "Contents" ) )
	ent:Setcount( self:GetData( "Amount" ) )	
	ent:Setowning_ent( self:GetData( "Owner" ) )
end

function ITEM:Use( pl )
	self:SetData( "Amount", self:GetData( "Amount" ) -  1 )
	pl:Give( CustomShipments[ self:GetData( "Contents" ) ].entity )
	
	if ( self:GetData( "Amount" ) < 1 ) then
		return true
	end
end