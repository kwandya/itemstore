itemstore.items = {}
itemstore.items.Registered = {}
itemstore.items.Pickups = {}

local Item = {}

function Item:Run( funcname, ... )
	local func = self[ funcname ]
	
	if ( func ) then
		return func( self, ... )
	end
end

function Item:GetName()
	return self.Name
end

function Item:GetDescription()
	return self.Description
end

function Item:GetModel()
	return self.Model
end

function Item:CanPickup( pl, ent )
	return true
end

function Item:Pickup( pl, ent )
end

function Item:Drop( pl, ent )
end

function Item:SpawnEntity( pos )
	local ent = ents.Create( "itemstore_item" )
	ent:SetItem( self )
	ent:SetPos( pos )
	
	return ent
end

function Item:SetData( index, value )
	self.Data[ index ] = value
end

function Item:GetData( index )
	return self.Data[ index ]
end

function Item:Overflow( pl, ent )
	self:Drop( pl, ent )
end

function Item:RegisterPickup( classname )
	itemstore.items.RegisterPickup( classname, self.UniqueName )
end;

function itemstore.items.RegisterPickup( classname, itemname )
	itemstore.items.Pickups[ classname ] = itemname
end

function itemstore.items.CanPickup( classname )
	if ( itemstore.items.Pickups[ classname ] and not itemstore.config.RestrictedItems[ classname ] ) then
		return true
	end
	
	return false
end

function itemstore.items.Exists( itemtype )
	if ( itemstore.items.Registered[ itemtype ] ) then
		return true
	end
	
	return false
end

function itemstore.items.Load( filename )
	local name = string.match( filename, "^(.+).lua$" )
	
	if ( name ) then
		ITEM = setmetatable( {}, { __index = Item } )
		ITEM.UniqueName = name
		
		if SERVER then AddCSLuaFile( "items/" .. filename ) end
		include( "items/" .. filename )
		
		if ( ITEM.Base ) then
			if ( itemstore.items.Exists( ITEM.Base ) ) then
				setmetatable( ITEM, { __index = itemstore.items.Registered[ ITEM.Base ] } )
			end
		end
		
		ITEM:Run( "Load" )
		
		itemstore.items.Registered[ name ] = ITEM
		
		ITEM = nil
	end
end

for _, filename in ipairs( file.Find( "itemstore/items/*.lua", "LUA" ) ) do
	itemstore.items.Load( filename )
end

function itemstore.items.New( itemtype )
	local itembase = itemstore.items.Registered[ itemtype ]
	
	if ( itembase ) then
		local item = setmetatable( { Data = {} }, { __index = itembase } )
		item:Run( "Initialize" )
		
		return item
	end
end

if SERVER then
	function itemstore.items.CreateEntity( item, pos )
		local ent = item:Run( "SpawnEntity", pos )
		item:Run( "LoadData", ent )
		
		return ent
	end
end