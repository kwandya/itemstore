itemstore.config = {}

-- Restricted items
-- Change any of the falses to true to restrict picking up that item
itemstore.config.RestrictedItems = {
	drug = false,
	drug_lab = false,
	food = false,
	gunlab = false,
	microwave = false,
	money_printer = false,
	spawned_food = false,
	spawned_shipment = false,
	spawned_weapon = false,
	
	durgz_alcohol = false,
	durgz_aspirin = false,
	durgz_cigarette = false,
	durgz_cocaine = false, 
	durgz_heroine = false,
	durgz_lsd = false,
	durgz_mushroom = false,
	durgz_pcp = false,
	durgz_weed = false
}

-- Sets the inventory's position to be at the left side of the screen
itemstore.config.InventoryAtLeft = false

-- The player's inventory size, width and height respectively
itemstore.config.InventorySize = { 4, 2 }

-- The bank's size, same parameters as the player's inventory.
itemstore.config.BankSize = { 8, 4 }

-- The time in seconds that the player has to wait before being able to pick up another item
itemstore.config.PickupCooldown = 1

-- Holding the context menu key will open the inventory (HERE YOU FUCKING GO, STOP ASKING PLEASE)
itemstore.config.ContextOpensInventory = true

-- Give every player the pickup SWEP on spawn.
itemstore.config.GivePickupSWEP = true

-- These are per-rank inventory sizes. Some examples are below. Format is rank = { width, height }
-- You MUST put in the inventories for ALL ranks you want. Ranks will not be inherited.
-- For example, superadmin AND admin must both be defined, even if they are the same size.
itemstore.config.RankSizes = {
	superadmin = { 10, 5 },
	admin = { 10, 3 },
	donator = { 10, 3 },
}

-- How far the player's pickup "reach" is in hammer units
itemstore.config.PickupDistance = 150

-- The colour of the windows in R, G, B, A 0-255 format.
itemstore.config.WindowColour = Color( 0, 0, 0, 200 )
itemstore.config.TitleColour = Color( 255, 255, 255 )
itemstore.config.SlotColour = Color( 0, 0, 0, 200 )