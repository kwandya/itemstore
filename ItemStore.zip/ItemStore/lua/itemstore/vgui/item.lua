local PANEL = {}

AccessorFunc( PANEL, "Item", "Item" )
AccessorFunc( PANEL, "ContainerID", "ContainerID" )
AccessorFunc( PANEL, "Slot", "Slot" )

function PANEL:Init()
	self.BaseClass.Init( self )
end

function PANEL:Paint()
	surface.SetDrawColor( itemstore.config.SlotColour )
	surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
	
	self.BaseClass.Paint( self )
end

function PANEL:PerformLayout()
	if ( self:GetItem() ) then
		self:SetTooltip( self:GetItem():GetName() .. "\n" .. self:GetItem():GetDescription() )
		self:SetModel( self:GetItem():GetModel() )
		
		min, max = self.Entity:GetRenderBounds()
		
		self:SetCamPos( Vector( 0.5, 0.5, 0.5 ) * min:Distance( max ) )
		self:SetLookAt( ( min + max ) / 2 )
	end
end

vgui.Register( "ItemStoreItem", PANEL, "DModelPanel" )