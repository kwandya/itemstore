ENT.Type = "anim"

ENT.PrintName = "Bank"

ENT.Spawnable = true
ENT.AdminSpawnable = true

if SERVER then
	AddCSLuaFile()
	
	ENT.Inventories = {}
	
	function ENT:Initialize()
		self:SetModel( "models/props_lab/reciever_cart.mdl" )
		
		self:PhysicsInit( SOLID_VPHYSICS )
		self:SetMoveType( MOVETYPE_VPHYSICS )
		self:SetSolid( SOLID_VPHYSICS )
		self:SetUseType( SIMPLE_USE )
		
		self:GetPhysicsObject():EnableMotion( false )
	end
	
	function ENT:SpawnFunction( pl, trace, class )
		local ent = ents.Create( class )
		ent:SetPos( trace.HitPos + trace.HitNormal * 16 )
		ent:Spawn()
		
		return ent
	end
	
	function ENT:CreateAccount( pl )
		local acc = itemstore.containers.New( itemstore.config.BankSize[ 1 ] * itemstore.config.BankSize[ 2 ] )
		acc:SetPlayerPermissions( pl, true, true )
		
		self.Inventories[ pl ] = acc
		
		return self.Inventories[ pl ]
	end
	
	function ENT:Use( pl )
		if ( IsValid( pl ) and pl:IsPlayer() ) then
			if not ( self.Inventories[ pl ] ) then
				self:CreateAccount( pl )
				
				local items = itemstore.data.LoadPlayerBank( pl )
				if ( items ) then
					self.Inventories[ pl ].Items = items
					self.Inventories[ pl ]:Sync()
				end
			end
			
			self.Inventories[ pl ]:SetPlayerPermissions( pl, true, true )
			itemstore.containers.Open( pl, self.Inventories[ pl ], "Bank", itemstore.config.BankSize[ 1 ], itemstore.config.BankSize[ 2 ] )
		end
	end
	
	concommand.Add( "itemstore_savebanks", function( pl )
		if ( pl:IsSuperAdmin() ) then
			itemstore.data.SaveBanks()
			pl:PrintMessage( HUD_PRINTCONSOLE, "Bank save OK!" )
		end
	end )
	
	hook.Add( "InitPostEntity", "ItemStoreLoadBanks", function()
		local banks = itemstore.data.LoadBanks()
		
		if ( banks ) then
			for _, data in ipairs( banks ) do
				local bank = ents.Create( "itemstore_bank" )
				bank:SetPos( data.Position )
				bank:SetAngles( data.Angles )
				bank:Spawn()
			end
		end
	end )
	
	-- this hacked together mess brought to you by your friendly neighborhood spiderme
	local NextThink = 0
	hook.Add( "Tick", "ItemStoreBankPermissions", function()
		if ( NextThink < CurTime() ) then
			local banks = ents.FindByClass( "itemstore_bank" )
			
			if ( IsValid( banks[ 1 ] ) ) then
				for pl, acc in pairs( banks[ 1 ].Inventories ) do
					if ( IsValid( pl ) ) then
						local withinrange = false
						for _, bank in ipairs( banks ) do
							if ( pl:GetPos():Distance( bank:GetPos() ) < 250 ) then
								withinrange = true
							end
						end
						
						if not ( withinrange ) then
							acc:SetPlayerPermissions( pl, false, false )
						end
					end
				end
			end
			
			NextThink = CurTime() + 1
		end
	end )
else
	function ENT:Draw()
		self:DrawModel()
		
		local text = "Bank"
		local font = "DermaDefaultBold"
		
		surface.SetFont( font )
		local textw, texth = surface.GetTextSize( text )
		local w = 5 + textw + 5
		local h = 2 + texth + 2
		local x, y = -w / 2, -h / 2
		
		cam.Start3D2D( self:GetPos() + self:GetAngles():Up() * 50, Angle( 0, CurTime() * 45, 90 ), 1 )
			surface.SetDrawColor( Color( 0, 0, 0, 200 ) )
			surface.DrawRect( x, y, w, h )
			
			draw.SimpleTextOutlined( text, font, 0, 0, Color( 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0 ) )
		cam.End3D2D()
	end
end